package edu.upenn.cis.cis455.webserver;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class myHttpServlet extends HttpServlet{

	String root_dir;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4886823538838413973L;

	//default constructor
    public myHttpServlet(String root){
    	root_dir = root;
    }
    
    private boolean validatePath(String path){
    	
    	
    	//TODO: check if the path is trying to access a location they dont have permission to access
    	/*if(){
    		
    	}*/
    	return true;
    	
    }
    
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
    	
    	// get the path and validate it does not try to access unaccessible directories
    	
    	String path = req.getPathInfo();
    	
    	if(!validatePath(path)){
    		//403 forbidden
    	}
    	else{
    		
    		File file = new File(path);
    		BufferedReader reader = null;
    		
    		try{
    			
    			reader = new BufferedReader(new FileReader(file));
    			StringBuffer buff = new StringBuffer();
    			
    			String line;
    			while( (line = reader.readLine()) != null){
    				buff.append(line);
    			}
    			
    			
    			PrintWriter out = res.getWriter();
    			
    			//set content type
    			//res.setContentType("text/plain");
    			
    			//write the entire output to response?
    			out.write(buff.toString());
    			
    			
    		}catch (FileNotFoundException e){
    			// 404
    			e.printStackTrace();
    		}catch (IOException e){
    			// 400???
    			e.printStackTrace();
    		}
    		
    		
    	}
    	
    	// get the file from root directory and write to the res output writer.
    	
    	
    	
    }
    
    
}
