package edu.upenn.cis.cis455.webserver;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import org.apache.log4j.Logger;

public class myServer extends Thread{
	
	Logger log = Logger.getLogger(myServer.class);
	
	/** 
	   Class to hold boolean that will be set when a workerThread receives a /shutdown request
	   it will immediately be seen accross all threads who can gracefully begin shutting down.
	   after receiving this flag, the server will also begin refusing connections while waiting
	   for threads to finish handling their requests. 
	**/
	
	class ShutdownControl {
		public volatile boolean shutdown_requested = false;
	}
	
	final ShutdownControl shutdown = new ShutdownControl();
	
	//Instance Variables
	ServerSocket serverSocket;
	int port;
	String root_dir;
	List<workerThread> threadPool = new ArrayList<workerThread>();
	myBlockingQueue sock_q = new myBlockingQueue(50); // 50 is default backlog
	final int num_threads = 5;
	
	
	// Public Constructor
	public myServer(int p, String r){
		port = p;
		root_dir = r;
	}
	
	//for logging pretty-printing server
	private String serverMessage(String msg){
		StringBuffer m = new StringBuffer();
		m.append("HttpServer: ");
		m.append(msg);
		return m.toString();
	}
	
	// run function
	public void run(){
		
		for(int i = 0; i < num_threads; i++){
			workerThread t = new workerThread(i,"INITIALIZED", sock_q, root_dir, shutdown); 
			threadPool.add(t);
		}
		
		// class that hold refs to all threads so that each individual thread can query 
		//  the status of other threads if a control page is requested of them.
		statusHandle stats = new statusHandle(threadPool);
		
		//start threads in threadPool
		for(workerThread t : threadPool){
			t.setStatusHandle(stats);
			t.start();
		}
		
		
		// initialize server socket
		try {
			log.debug(serverMessage("Listening for connections"));
			
			serverSocket = new ServerSocket(port);
			
			serverSocket.setSoTimeout(2000);
			
		    while (true){
		    	
		    	try{
		    		if(shutdown.shutdown_requested == false){

		    			Socket clientSocket = serverSocket.accept();
		    			log.debug(serverMessage("Got a Connection!"));
		    			
		    			clientSocket.setSoTimeout(30000);

		    			// Give socket to a thread to process the request

		    			log.debug(serverMessage("accept returned"));
		    			synchronized(sock_q){
		    				log.debug(serverMessage("Enqueuing Socket: " + clientSocket.toString()));
		    				//sock_q.add(clientSocket);
		    				try {
								sock_q.enqueue(clientSocket);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
		    				//sock_q.notify();
		    			}
		    		}else{
		    			
		    			log.debug(serverMessage("accept returned"));
		    			// propagate shutdown to all threads
		    			for(workerThread t : threadPool){
		    				t.setShutdown();
		    			}
		    			synchronized(sock_q){
		    				sock_q.notifyAll();
		    			}
		    			break;
		    		}
		    	} catch (SocketTimeoutException timeout ){ // hacky way of doing things to not block, in case there is a shutdown flag.
					// do nothing just let it continue...
					//log.debug("Server Socket accept() timed out");
		    	}
		    }		    
		} catch (SecurityException se){
			se.printStackTrace();
			
		} catch (IllegalArgumentException ie) {
			ie.printStackTrace();
			
		} catch (SocketException ske){
			ske.printStackTrace();
			
		} catch (IOException ie){
			ie.printStackTrace();
			
		}finally // close our resources
		{
			try {
				
				serverSocket.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		log.debug("Waiting for threads to die");
		//Wait for threads to die
		for(workerThread t : threadPool){
			try {
				t.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
	}
}
